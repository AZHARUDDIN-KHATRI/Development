package com.btech.studentai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentPerformanceAiApplication {
    public static void main(String[] args) {
        SpringApplication.run(StudentPerformanceAiApplication.class, args);
    }
}
