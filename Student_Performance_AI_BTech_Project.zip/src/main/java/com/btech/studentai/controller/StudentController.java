package com.btech.studentai.controller;

import com.btech.studentai.model.Student;
import com.btech.studentai.repository.StudentRepository;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/students")
@CrossOrigin
public class StudentController {
    private final StudentRepository repository;
    public StudentController(StudentRepository repository){this.repository=repository;}

    @GetMapping public List<Student> all(){return repository.findAll();}
    @GetMapping("/{id}") public Student one(@PathVariable Long id){
        return repository.findById(id).orElseThrow(() -> new org.springframework.web.server.ResponseStatusException(HttpStatus.NOT_FOUND,"Student not found"));
    }
    @PostMapping public ResponseEntity<Student> create(@Valid @RequestBody Student student){
        student.setId(null); return ResponseEntity.status(HttpStatus.CREATED).body(repository.save(student));
    }
    @PutMapping("/{id}") public Student update(@PathVariable Long id,@Valid @RequestBody Student input){
        Student s=one(id); s.setName(input.getName()); s.setEmail(input.getEmail());
        s.setAttendance(input.getAttendance()); s.setStudyHoursPerWeek(input.getStudyHoursPerWeek());
        s.setAssignmentScore(input.getAssignmentScore()); s.setPreviousScore(input.getPreviousScore());
        return repository.save(s);
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id){
        repository.delete(one(id)); return ResponseEntity.noContent().build();
    }
}
