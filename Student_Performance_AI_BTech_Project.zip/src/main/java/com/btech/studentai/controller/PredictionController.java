package com.btech.studentai.controller;

import com.btech.studentai.dto.*;
import com.btech.studentai.service.PredictionService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class PredictionController {
    private final PredictionService service;
    public PredictionController(PredictionService service){this.service=service;}

    @PostMapping("/predictions")
    public PredictionResponse predict(@Valid @RequestBody PredictionRequest request) throws Exception {
        return service.predict(request);
    }
    @GetMapping("/model")
    public Map<String,Object> modelInfo(){return service.modelInfo();}
}
