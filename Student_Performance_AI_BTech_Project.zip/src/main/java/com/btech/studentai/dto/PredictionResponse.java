package com.btech.studentai.dto;

public record PredictionResponse(String prediction, double confidence, String recommendation, String model) {}
