package com.btech.studentai.dto;

import jakarta.validation.constraints.*;

public record PredictionRequest(
    @DecimalMin("0.0") @DecimalMax("100.0") double attendance,
    @DecimalMin("0.0") @DecimalMax("24.0") double studyHoursPerWeek,
    @Min(0) @Max(100) int assignmentScore,
    @Min(0) @Max(100) int previousScore
) {}
