package com.btech.studentai.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "students")
public class Student {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank @Column(nullable = false) private String name;
    @NotBlank @Column(nullable = false, unique = true) private String email;
    @DecimalMin("0.0") @DecimalMax("100.0") private double attendance;
    @DecimalMin("0.0") @DecimalMax("24.0") private double studyHoursPerWeek;
    @Min(0) @Max(100) private int assignmentScore;
    @Min(0) @Max(100) private int previousScore;

    public Student() {}
    public Student(String name, String email, double attendance, double studyHoursPerWeek, int assignmentScore, int previousScore) {
        this.name=name; this.email=email; this.attendance=attendance; this.studyHoursPerWeek=studyHoursPerWeek;
        this.assignmentScore=assignmentScore; this.previousScore=previousScore;
    }
    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public String getName(){return name;} public void setName(String v){name=v;}
    public String getEmail(){return email;} public void setEmail(String v){email=v;}
    public double getAttendance(){return attendance;} public void setAttendance(double v){attendance=v;}
    public double getStudyHoursPerWeek(){return studyHoursPerWeek;} public void setStudyHoursPerWeek(double v){studyHoursPerWeek=v;}
    public int getAssignmentScore(){return assignmentScore;} public void setAssignmentScore(int v){assignmentScore=v;}
    public int getPreviousScore(){return previousScore;} public void setPreviousScore(int v){previousScore=v;}
}
