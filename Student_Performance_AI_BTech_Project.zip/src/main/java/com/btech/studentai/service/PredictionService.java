package com.btech.studentai.service;

import com.btech.studentai.dto.*;
import jakarta.annotation.PostConstruct;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import weka.classifiers.trees.RandomForest;
import weka.core.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Service
public class PredictionService {
    private RandomForest model;
    private Instances trainingData;
    private final List<String> labels = List.of("AT_RISK", "PASS");

    @PostConstruct
    public void trainOnStartup() {
        try {
            trainingData = loadTrainingData();
            model = new RandomForest();
            model.setNumIterations(120);
            model.setMaxDepth(8);
            model.setSeed(42);
            model.buildClassifier(trainingData);
        } catch (Exception e) {
            throw new IllegalStateException("Could not train the prediction model", e);
        }
    }

    private Instances loadTrainingData() throws Exception {
        ArrayList<Attribute> attributes = new ArrayList<>();
        attributes.add(new Attribute("attendance"));
        attributes.add(new Attribute("study_hours"));
        attributes.add(new Attribute("assignment_score"));
        attributes.add(new Attribute("previous_score"));
        attributes.add(new Attribute("outcome", new ArrayList<>(labels)));
        Instances data = new Instances("StudentPerformance", attributes, 100);
        data.setClassIndex(data.numAttributes() - 1);

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new ClassPathResource("data/student_performance.csv").getInputStream(), StandardCharsets.UTF_8))) {
            String line = reader.readLine(); // header
            while ((line = reader.readLine()) != null) {
                if (line.isBlank()) continue;
                String[] p = line.split(",");
                if (p.length != 5) continue;
                double[] values = new double[5];
                for (int i=0; i<4; i++) values[i] = Double.parseDouble(p[i].trim());
                values[4] = labels.indexOf(p[4].trim());
                if (values[4] >= 0) data.add(new DenseInstance(1.0, values));
            }
        }
        if (data.numInstances() < 10) throw new IllegalStateException("Training dataset is too small");
        return data;
    }

    public PredictionResponse predict(PredictionRequest request) throws Exception {
        if (model == null) trainOnStartup();
        Instance instance = new DenseInstance(trainingData.numAttributes());
        instance.setDataset(trainingData);
        instance.setValue(0, request.attendance());
        instance.setValue(1, request.studyHoursPerWeek());
        instance.setValue(2, request.assignmentScore());
        instance.setValue(3, request.previousScore());
        instance.setMissing(4);

        double[] probabilities = model.distributionForInstance(instance);
        int predictedIndex = Utils.maxIndex(probabilities);
        String prediction = trainingData.classAttribute().value(predictedIndex);
        double confidence = Math.round(probabilities[predictedIndex] * 1000.0) / 10.0;
        String recommendation = prediction.equals("PASS")
                ? "Maintain consistent attendance and weekly revision."
                : "Meet your faculty mentor, improve attendance, and create a weekly study plan.";
        return new PredictionResponse(prediction, confidence, recommendation, "Weka RandomForest (120 trees)");
    }

    public Map<String, Object> modelInfo() {
        Map<String,Object> info = new LinkedHashMap<>();
        info.put("algorithm", "Random Forest"); info.put("trees", 120);
        info.put("trainingRows", trainingData == null ? 0 : trainingData.numInstances());
        info.put("features", List.of("attendance", "studyHoursPerWeek", "assignmentScore", "previousScore"));
        info.put("classes", labels);
        info.put("note", "Educational prototype; predictions are estimates, not guarantees.");
        return info;
    }
}
