# Push this project to GitHub

Create an empty repository on GitHub named `student-performance-ai` (do not initialize it with a README or license).

Run these commands from the project root:

```bash
git init
git add .
git commit -m "Initial commit: Student Performance AI BTech project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/student-performance-ai.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.

For later changes:
```bash
git add .
git commit -m "Describe your changes"
git push
```

Never commit database passwords, API keys, personal student data, or `.env` files. If Git asks for authentication, use GitHub's browser sign-in or a personal access token; do not put the token directly in the remote URL.
