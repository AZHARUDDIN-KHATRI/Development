# Final-Year B.Tech Project Report
## Student Performance Prediction System Using Machine Learning

### 1. Abstract
This project demonstrates an academic-support system that manages student records and estimates whether a student may be at risk of not passing. A Random Forest classifier from Weka uses four input features: attendance percentage, weekly study hours, assignment score, and previous score. A Spring Boot REST API exposes student CRUD operations, prediction, and model metadata. H2 provides a frictionless local database and an optional MySQL profile supports a conventional relational database deployment.

### 2. Problem Statement
Academic staff may need a structured way to review student indicators and identify cases that could benefit from additional support. Manual review can be time-consuming. This prototype explores how a supervised machine-learning model can produce an early-warning estimate while keeping the result explainable through a recommendation message.

### 3. Objectives
- Build a Java-based backend for student record management.
- Train and run a Random Forest classifier using Weka.
- Expose prediction and management operations through REST endpoints.
- Persist student information using JPA with H2/MySQL.
- Document limitations, responsible use, and future improvements.

### 4. Scope
The prototype is intended for demonstration and academic evaluation. It does not include a production web UI, authentication, authorization, or institutional integrations. The sample dataset is synthetic and is not evidence of real-world model performance.

### 5. System Architecture
1. Client (curl, Postman, or future frontend) sends JSON over HTTP.
2. Spring Boot controllers validate requests.
3. StudentController uses Spring Data JPA to persist records.
4. PredictionController forwards validated features to PredictionService.
5. PredictionService trains a Weka Random Forest from the packaged CSV at startup and returns a predicted class and probability.
6. H2 or MySQL stores student records.

### 6. Machine Learning Methodology
**Algorithm:** Random Forest classification.

**Input features:** attendance (0–100), study hours per week (0–24), assignment score (0–100), previous score (0–100).

**Target classes:** `PASS`, `AT_RISK`.

A Random Forest combines multiple decision trees and aggregates their predictions. The implementation uses 120 trees, maximum depth 8, and seed 42. These are demonstration parameters, not an optimized configuration.

**Important evaluation note:** The bundled CSV is small and synthetic. A meaningful project evaluation must use a representative, permitted dataset and a held-out test set or cross-validation. Report accuracy, precision, recall, F1-score, and confusion matrix. Do not claim performance metrics until they have actually been measured.

### 7. Database Design
The `students` table contains:
| Field | Type | Constraint |
|---|---|---|
| id | BIGINT | Primary key, auto increment |
| name | VARCHAR(150) | Not null |
| email | VARCHAR(190) | Not null, unique |
| attendance | DOUBLE | 0–100 |
| study_hours_per_week | DOUBLE | 0–24 |
| assignment_score | INT | 0–100 |
| previous_score | INT | 0–100 |

The JPA entity creates/updates the schema in development. `database/schema.sql` creates the MySQL database and equivalent table.

### 8. API Design
- `GET /api/students`: list records
- `GET /api/students/{id}`: retrieve one record
- `POST /api/students`: add a record
- `PUT /api/students/{id}`: update a record
- `DELETE /api/students/{id}`: delete a record
- `POST /api/predictions`: estimate outcome
- `GET /api/model`: view model metadata

### 9. Testing Plan
Use Postman or curl to test:
1. Add a valid student and verify HTTP 201.
2. Retrieve the list and individual student.
3. Update a record and verify changed values.
4. Delete a record and verify it is absent.
5. Submit a valid prediction request and verify the response contains prediction, confidence, recommendation, and model.
6. Submit out-of-range values and verify HTTP 400.
7. Inspect `/api/model` for algorithm and training row count.

### 10. Limitations and Ethical Considerations
- Synthetic training examples do not represent actual student populations.
- Prediction confidence is not a guarantee of an outcome.
- Attendance and study hours may correlate with circumstances outside a student's control.
- Data must be collected lawfully, minimized, secured, and used with appropriate consent and oversight.
- A prediction must never be used as the sole basis for grading, admission, discipline, or access to support.

### 11. Future Enhancements
- Add authentication and role-based access control.
- Build a React/Angular dashboard.
- Add a reproducible offline training/evaluation pipeline and model versioning.
- Store prediction history and model evaluation reports.
- Add explainability (e.g., feature importance) and fairness monitoring.
- Deploy using Docker and a managed database.

### 12. Conclusion
The project integrates a Java REST backend, relational persistence, and a Weka machine-learning classifier. It provides a foundation for demonstrating an end-to-end ML application and can be extended with validated data, rigorous evaluation, security, and a user interface.
