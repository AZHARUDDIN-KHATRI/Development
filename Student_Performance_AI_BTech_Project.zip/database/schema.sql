CREATE DATABASE IF NOT EXISTS student_ai;
USE student_ai;

CREATE TABLE IF NOT EXISTS students (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  attendance DOUBLE NOT NULL,
  study_hours_per_week DOUBLE NOT NULL,
  assignment_score INT NOT NULL,
  previous_score INT NOT NULL
);
