# Student Performance Prediction System (AI/ML)

An advanced final-year B.Tech project built with **Java 17, Spring Boot, MySQL/H2, and Weka Random Forest**. It provides student record management through a REST API and predicts an estimated academic outcome (`PASS` / `AT_RISK`) from attendance, weekly study hours, assignment score, and previous score.

> **Academic-use note:** This is a learning prototype with a small synthetic demonstration dataset. Its predictions are not validated for real academic decisions. Replace the sample data with appropriately consented, representative data and evaluate fairness and accuracy before any real-world use.

## Features
- REST API for creating, reading, updating, and deleting student records.
- Weka Random Forest classifier trained at application startup.
- Prediction confidence and a plain-language study recommendation.
- Request validation and consistent error responses.
- H2 file database for a quick local run; optional MySQL profile.
- Model metadata endpoint and sample CSV training data.

## Technology
Java 17 · Spring Boot 3.3.5 · Spring Data JPA · Weka 3.8.6 · MySQL 8 (optional) · H2 · Maven

## Requirements
- JDK 17+
- Maven 3.8+
- Optional: MySQL 8+

## Run locally (H2, no MySQL required)
```bash
git clone https://github.com/YOUR-USERNAME/student-performance-ai.git
cd student-performance-ai
mvn clean spring-boot:run
```
The API starts at `http://localhost:8080`. H2 data is stored in `./data`.

## Run with MySQL
1. Start MySQL and execute `database/schema.sql`.
2. Set credentials in your shell (do not commit real passwords):
```bash
export DB_URL='jdbc:mysql://localhost:3306/student_ai?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC'
export DB_USERNAME='root'
export DB_PASSWORD='your-local-password'
```
3. Start with the MySQL profile:
```bash
mvn spring-boot:run -Dspring-boot.run.profiles=mysql
```

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/students` | List students |
| GET | `/api/students/{id}` | Get one student |
| POST | `/api/students` | Create student |
| PUT | `/api/students/{id}` | Update student |
| DELETE | `/api/students/{id}` | Delete student |
| POST | `/api/predictions` | Predict outcome |
| GET | `/api/model` | Model metadata |

### Example: create a student
```bash
curl -X POST http://localhost:8080/api/students \
  -H 'Content-Type: application/json' \
  -d '{"name":"Aarav Sharma","email":"aarav@example.com","attendance":88,"studyHoursPerWeek":12,"assignmentScore":82,"previousScore":79}'
```

### Example: request a prediction
```bash
curl -X POST http://localhost:8080/api/predictions \
  -H 'Content-Type: application/json' \
  -d '{"attendance":88,"studyHoursPerWeek":12,"assignmentScore":82,"previousScore":79}'
```
Response shape:
```json
{
  "prediction": "PASS",
  "confidence": 87.5,
  "recommendation": "Maintain consistent attendance and weekly revision.",
  "model": "Weka RandomForest (120 trees)"
}
```
Confidence is an illustrative model probability, not a guarantee.

### Example: inspect model
```bash
curl http://localhost:8080/api/model
```

## Training data and model
Training data is at `src/main/resources/data/student_performance.csv`. The application reads it and trains a Weka RandomForest with a fixed seed and 120 trees during startup. The included rows are synthetic examples intended only to demonstrate the pipeline. For a serious research submission:
1. Collect/obtain permission for a representative, privacy-protected dataset.
2. Keep a separate train/test split and report accuracy, precision, recall, F1-score, and confusion matrix.
3. Check class imbalance, data leakage, and subgroup fairness.
4. Tune hyperparameters using cross-validation; document dataset provenance.
5. Do not use predictions as the sole basis for student evaluation.

## Project structure
```text
src/main/java/com/btech/studentai/
  controller/       REST controllers
  dto/              Request/response records
  exception/        API error handling
  model/            JPA entity
  repository/       Spring Data repository
  service/          Weka model training and inference
src/main/resources/
  application.properties
  application-mysql.properties
  data/student_performance.csv
database/schema.sql
docs/PROJECT_REPORT.md
```

## Troubleshooting
- `mvn: command not found`: install Maven and reopen the terminal.
- `java version` below 17: install JDK 17 and set `JAVA_HOME`.
- MySQL connection failure: check that MySQL is running, the database exists, and environment variables are correct. Use the default H2 profile if you only want to test the project.
- Port 8080 busy: set `server.port=8081` in `application.properties`.

## License
MIT — see `LICENSE`.
